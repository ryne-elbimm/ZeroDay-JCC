#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

char flag[256];

// Build with:
// gcc -g -fno-stack-protector -no-pie -z execstack -o chall chall.c

void crash_handler(int sig)
{
    FILE *f = fopen("flag.txt", "r");
    if (f)
    {
        fgets(flag, sizeof(flag), f);
        fclose(f);
        printf("\nYou crashed my server! Here's a flag for you: %s\n", flag);
    }
    else
    {
        printf("\nYou crashed my server! I don't have a flag for you though\n");
    }
    exit(0);
}

int main(void)
{
    char name[256];

    signal(SIGSEGV, crash_handler);

    printf("What's your name: ");
    fflush(stdout);
    gets(name);

    printf("Welcome to JCC, %s!", name);
    return 0;
}
